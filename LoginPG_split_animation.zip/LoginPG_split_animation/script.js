document.getElementById('toggle-btn').addEventListener('click', function () {
    const container = document.getElementById('container');
    const leftSection = document.getElementById('left-section');
    const rightSection = document.getElementById('right-section');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const welcomeText = document.getElementById('welcome-text');
    const instructionText = document.getElementById('instruction-text');

    // Toggle forms and sections
    if (container.classList.contains('swapped')) {
        // Switch to login
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
        welcomeText.textContent = 'Welcome Back';
        instructionText.textContent = 'Login to continue';
        this.innerHTML = '<span>Go to Register</span>';
    } else {
        // Switch to register
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
        welcomeText.textContent = 'Create Account';
        instructionText.textContent = 'Register to continue';
        this.innerHTML = '<span>Go to Login</span>';
    }

    container.classList.toggle('swapped'); // Toggle the swapped class
});
